# RetroSocial — real online version

Это серверный вариант с регистрацией, JWT-входом, PostgreSQL, общей лентой и лайками.

## Для Render
- Build Command: `npm install`
- Start Command: `npm start`
- Environment:
  - `DATABASE_URL` — строка подключения PostgreSQL
  - `JWT_SECRET` — длинная случайная строка

Нужна PostgreSQL-база (например, Neon/Supabase/Render Postgres). После первого запуска таблицы создаются автоматически.

Важно: это рабочая основа, но не готовая крупная соцсеть: нет восстановления пароля, модерации, загрузки фото и защиты от спама.
