const express=require("express");
const path=require("path");
const bcrypt=require("bcryptjs");
const jwt=require("jsonwebtoken");
const {Pool}=require("pg");

const app=express(), PORT=process.env.PORT||3000;
const JWT_SECRET=process.env.JWT_SECRET||"change-this-secret";
if(!process.env.DATABASE_URL) console.warn("DATABASE_URL is not set");
const pool=new Pool({connectionString:process.env.DATABASE_URL,ssl:process.env.DATABASE_URL?{rejectUnauthorized:false}:false});

app.use(express.json({limit:"1mb"}));
app.use(express.static(path.join(__dirname,"public")));

async function init(){
 if(!process.env.DATABASE_URL) return;
 await pool.query(`CREATE TABLE IF NOT EXISTS users(
   id SERIAL PRIMARY KEY, username TEXT UNIQUE NOT NULL, password TEXT NOT NULL,
   created_at TIMESTAMPTZ DEFAULT now()
 )`);
 await pool.query(`CREATE TABLE IF NOT EXISTS posts(
   id SERIAL PRIMARY KEY, user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
   body TEXT NOT NULL, created_at TIMESTAMPTZ DEFAULT now()
 )`);
 await pool.query(`CREATE TABLE IF NOT EXISTS likes(
   user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
   post_id INTEGER REFERENCES posts(id) ON DELETE CASCADE,
   PRIMARY KEY(user_id,post_id)
 )`);
}

function auth(req,res,next){
 try{const token=(req.headers.authorization||"").replace("Bearer ","");req.user=jwt.verify(token,JWT_SECRET);next()}
 catch(e){res.status(401).json({error:"Нужен вход"})}
}

app.post("/api/register",async(req,res)=>{
 try{
  const {username,password}=req.body;
  if(!username||!password||username.length<2||password.length<4)return res.status(400).json({error:"Имя от 2 символов, пароль от 4"});
  const hash=await bcrypt.hash(password,10);
  const r=await pool.query("INSERT INTO users(username,password) VALUES($1,$2) RETURNING id,username",[username.trim(),hash]);
  res.json({token:jwt.sign(r.rows[0],JWT_SECRET),user:r.rows[0]});
 }catch(e){res.status(400).json({error:e.code==="23505"?"Такое имя уже занято":"Ошибка регистрации"})}
});
app.post("/api/login",async(req,res)=>{
 try{
  const r=await pool.query("SELECT id,username,password FROM users WHERE username=$1",[String(req.body.username||"").trim()]);
  if(!r.rowCount||!(await bcrypt.compare(req.body.password||"",r.rows[0].password)))return res.status(401).json({error:"Неверное имя или пароль"});
  const u={id:r.rows[0].id,username:r.rows[0].username};
  res.json({token:jwt.sign(u,JWT_SECRET),user:u});
 }catch(e){res.status(500).json({error:"Ошибка сервера"})}
});
app.get("/api/me",auth,(req,res)=>res.json(req.user));
app.get("/api/posts",async(req,res)=>{
 const r=await pool.query(`SELECT p.id,p.body,p.created_at,u.username,
 (SELECT count(*) FROM likes l WHERE l.post_id=p.id)::int likes
 FROM posts p JOIN users u ON u.id=p.user_id ORDER BY p.created_at DESC LIMIT 100`);
 res.json(r.rows);
});
app.post("/api/posts",auth,async(req,res)=>{
 const body=String(req.body.body||"").trim();
 if(!body||body.length>5000)return res.status(400).json({error:"Пустой или слишком длинный пост"});
 const r=await pool.query("INSERT INTO posts(user_id,body) VALUES($1,$2) RETURNING id,body,created_at",[req.user.id,body]);
 res.json({...r.rows[0],username:req.user.username,likes:0});
});
app.post("/api/posts/:id/like",auth,async(req,res)=>{
 await pool.query(`INSERT INTO likes(user_id,post_id) VALUES($1,$2) ON CONFLICT DO NOTHING`,[req.user.id,req.params.id]);
 const r=await pool.query("SELECT count(*)::int likes FROM likes WHERE post_id=$1",[req.params.id]);
 res.json(r.rows[0]);
});
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public/index.html")));
init().then(()=>app.listen(PORT,()=>console.log("RetroSocial running on "+PORT))).catch(console.error);
